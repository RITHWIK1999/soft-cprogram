/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,n1,n2,n3,i;
    printf("enter a number :");
    scanf("%d",&n);
    for (i=0;i<=n;i++)
 {
      n3=n1+n2;    
      n1=n2;
      n2=n3;  
      printf("%d",n3);
 }  
    
    

    return 0;
}
