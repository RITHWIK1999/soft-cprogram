#include <stdio.h>

int main()
 {
    int x,y,z;
    printf("Enter a number x: ");
    scanf("%d",&x);
    printf("enter a number y:");
    scanf("%d",&y);
    printf("enter a number z:");
    scanf("%d",&z);
    {
    if(x>y&x>z)
    printf("%d is greatest number amoung three ",x);
    if(y>x&y>z)
    printf("%d is greatest number amoung three ",y);
    if(z>x&z>y)
    printf("%d is greatest number  amoung three ",z);
   }

    return 0;
}