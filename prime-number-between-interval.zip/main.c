/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a,b,i,j,prime=0;
    printf("Enter a starting number :");
    scanf("%d",&a);
    printf("enter the Nth number :");
    scanf("%d",&b);
    for(i=a;i<=b;i++)
    {
        prime=0;
        for(j=2;j<i;j++)
        {
            if(i%j==0)
            {
                prime++;
            }
    }
        if(prime==0)
        printf("%d \n",i);
    }
       

    return 0;
}
