/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void prime();
void number();
void main()
{
    printf("Prime number inside a range \n");
    prime();
    number();
}
void prime()
{
 int a,b,i,j,prime=0;
    printf("Enter a starting number :");
    scanf("%d",&a);
    printf("enter the Nth number :");
    scanf("%d",&b);
    for(i=a;i<=b;i++)
    {
        prime=0;
        for(j=2;j<i;j++)
        {
            if(i%j==0)
            {
                prime++;
            }
    }
        if(prime==0)
        printf("%d \n",i);
    }
       
}
void number()
{
    printf("Prime numbers listed on top ^ \n");
}

