/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char ch2[20];
    char ch1[20]={'r','i','t','h','w','i','k','\0'};
    printf("The string is %d \n",strlen(ch1));
    printf("Enter a string to compare :");
    scanf("%s",&ch2);
    if(strcmp(ch1,ch2)==0)
    printf("The string are same");
    else
    printf("The string not same");
    

    return 0;
}