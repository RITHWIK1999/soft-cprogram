
#include <stdio.h>

int main()
{
    printf("name:\  RITHWIK\n""house name:\    Thazhathuveetil(House)\n""PH:\   8606036192\n""Paroppady");
        printf("\   Kozhikode");
    
    
    return 0;
}
