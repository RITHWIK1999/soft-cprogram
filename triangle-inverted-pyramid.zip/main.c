/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int rows,i,j,k;
    printf("enter number rows:");
    scanf("%d",&rows);
    for (i = rows; i >= 1; i--)
    {
      for ( k= 0; k< rows-i;k++)
         printf("  ");
      for (j = i; j <= 2 * i - 1;j++)
         printf("* ");
      for (j = 0; j < i - 1;j++)
         printf("* ");
      printf("\n");
   }
    return 0;
}