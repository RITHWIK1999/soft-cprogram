#include <stdio.h>

int main()
{
   int number;
   printf("Enter a Number");
   scanf("%d",&number);
   (number>=0)?(printf("THE NUMBER IS POSITIVE")):(printf("THE NUMBRR IS NEGATIVE"));

    return 0;
}
