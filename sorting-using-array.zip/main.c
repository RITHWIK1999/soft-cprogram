/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int i,j,temp;
    int a[10]={20,25,9,4,81,102,34,56,78};
    for(i=0;i<10;i++)
    {
        for(j=i+1;j<10;j++)
    {
    if(a[j]>a[i])
    {
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    }
    }
    printf("The sorted numbers are :\n");
    
for(i=0;i<10;i++)
{
    printf("%d \n",a[i]);
    
}
}