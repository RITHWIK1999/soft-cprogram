/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float p,r,t,n,ci;
    printf("enter the principle:");
    scanf("%f",&p);
    printf("enter the rate of interest:");
    scanf("%f",&r);
    printf("enter the tim period elapsede");
    scanf("%f",&t);
    
    ci=p*((1+r/100),t)-p;
    printf("the compound interest is:%f",ci);
    

    return 0;
}
