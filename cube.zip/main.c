
#include <stdio.h>

int main()
{
int number;
    printf("Enter A Number");
    scanf("%d",&number);
    printf("The Cube Of Number Is:%d",number*number*number);

    return 0;
}
