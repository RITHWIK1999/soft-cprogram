/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 #include<stdio.h>
 
void main ()

 {
     
 int arr[100],i,n,largest,sec_largest;
 
 printf("Enter the size of the array : ");
 scanf("%d",&n);
    printf("Enter the elements of the array : ");
 for(i = 0; i<n; i++)
 
 {
 scanf("%d",&arr[i]);
 }
    largest = arr[0];
        sec_largest = arr[1];
    for(i=0;i<n;i++)
{
    if(arr[i]>largest)
 {
    sec_largest = largest;
    largest = arr[i];
}
    else if (arr[i]>sec_largest && arr[i]!=largest)
 {
 sec_largest=arr[i];
 }
 }
 printf("largest = %d, second largest = %d",largest,sec_largest);
} 
