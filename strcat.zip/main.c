/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char ch2[20];
    char ch1[20];
    printf("enter a 1ST string :");
    scanf("%s",ch1);
    printf("Enter a 2nd string :");
    scanf("%s",ch2);
    strcat(ch1,ch2);
    printf("The string is:%s",ch1);
    
    
   

    return 0;
}