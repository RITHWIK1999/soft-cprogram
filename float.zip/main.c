#include <stdio.h>

int main()
{
float number;
    printf("Enter A Number");
    scanf("%f",&number);
    printf("The Cube Of Number Is:%f",number*number*number);

    return 0;
}
